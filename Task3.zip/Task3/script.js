// Quiz Data
const quizData = [
    {
        question: "What does CSS stand for?",
        options: [
            "Computer Style Sheets",
            "Cascading Style Sheets",
            "Creative Style Syntax",
            "Colorful Style Sheets"
        ],
        answer: 1
    },
    {
        question: "Which HTML tag is used to include JavaScript code?",
        options: [
            "<js>",
            "<javascript>",
            "<script>",
            "<code>"
        ],
        answer: 2
    },
    {
        question: "Which property is used for responsive design in CSS?",
        options: [
            "float",
            "media queries",
            "z-index",
            "overflow"
        ],
        answer: 1
    }
];

let currentQuestion = 0;
let score = 0;

const quizContainer = document.getElementById('quiz-container');
const nextBtn = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');

function showQuestion() {
    const q = quizData[currentQuestion];
    quizContainer.innerHTML = `<p>${q.question}</p>` +
        q.options.map((opt, i) =>
            `<label><input type="radio" name="option" value="${i}"> ${opt}</label><br>`
        ).join('');
    nextBtn.disabled = true;
}

quizContainer.addEventListener('change', (e) => {
    if (e.target.name === 'option') {
        nextBtn.disabled = false;
    }
});

nextBtn.addEventListener('click', () => {
    const selected = document.querySelector('input[name="option"]:checked');
    if (!selected) return;
    const answer = parseInt(selected.value);
    if (answer === quizData[currentQuestion].answer) {
        score++;
        quizContainer.innerHTML += '<p style="color:green;">Correct!</p>';
    } else {
        quizContainer.innerHTML += '<p style="color:red;">Wrong! Correct answer: ' + quizData[currentQuestion].options[quizData[currentQuestion].answer] + '</p>';
    }
    nextBtn.disabled = true;
    setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < quizData.length) {
            showQuestion();
        } else {
            quizContainer.innerHTML = '';
            scoreContainer.textContent = `Quiz finished! Your score: ${score} / ${quizData.length}`;
            nextBtn.style.display = 'none';
        }
    }, 1000);
});

showQuestion();

// API Fetching (Random Joke)
const fetchJokeBtn = document.getElementById('fetch-joke-btn');
const jokeP = document.getElementById('joke');

fetchJokeBtn.addEventListener('click', async () => {
    jokeP.textContent = 'Loading...';
    try {
        const res = await fetch('https://official-joke-api.appspot.com/random_joke');
        const data = await res.json();
        jokeP.textContent = `${data.setup} - ${data.punchline}`;
    } catch (err) {
        jokeP.textContent = 'Failed to fetch joke.';
    }
}); 