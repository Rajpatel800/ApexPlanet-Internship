// Product Listing with Filtering and Sorting

document.addEventListener('DOMContentLoaded', function() {
    const products = [
        { id: 1, name: 'Smartphone', category: 'electronics', price: 299, rating: 4.5, img: 'https://img.icons8.com/ios-filled/100/000000/smartphone.png' },
        { id: 2, name: 'Laptop', category: 'electronics', price: 799, rating: 4.7, img: 'https://img.icons8.com/ios-filled/100/000000/laptop.png' },
        { id: 3, name: 'T-Shirt', category: 'clothing', price: 19, rating: 4.1, img: 'https://img.icons8.com/ios-filled/100/000000/t-shirt.png' },
        { id: 4, name: 'Novel', category: 'books', price: 12, rating: 4.8, img: 'https://img.icons8.com/ios-filled/100/000000/book.png' },
        { id: 5, name: 'Headphones', category: 'electronics', price: 49, rating: 4.3, img: 'https://img.icons8.com/ios-filled/100/000000/headphones.png' },
        { id: 6, name: 'Jeans', category: 'clothing', price: 39, rating: 4.0, img: 'https://img.icons8.com/ios-filled/100/000000/jeans.png' },
        { id: 7, name: 'Cookbook', category: 'books', price: 25, rating: 4.6, img: 'https://img.icons8.com/ios-filled/100/000000/cookbook.png' },
    ];
    const categoryFilter = document.getElementById('categoryFilter');
    const sortOptions = document.getElementById('sortOptions');
    const productList = document.getElementById('productList');

    function renderProducts(list) {
        productList.innerHTML = '';
        if (list.length === 0) {
            productList.innerHTML = '<p>No products found.</p>';
            return;
        }
        list.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <img src="${product.img}" alt="${product.name}">
                <h4>${product.name}</h4>
                <div class="price">$${product.price}</div>
                <div class="rating">&#9733; ${product.rating}</div>
                <div class="category">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</div>
            `;
            productList.appendChild(card);
        });
    }

    function filterAndSort() {
        let filtered = products.slice();
        const cat = categoryFilter.value;
        const sort = sortOptions.value;
        if (cat !== 'all') {
            filtered = filtered.filter(p => p.category === cat);
        }
        if (sort === 'price-asc') {
            filtered.sort((a, b) => a.price - b.price);
        } else if (sort === 'price-desc') {
            filtered.sort((a, b) => b.price - a.price);
        } else if (sort === 'rating-desc') {
            filtered.sort((a, b) => b.rating - a.rating);
        }
        renderProducts(filtered);
    }

    categoryFilter.addEventListener('change', filterAndSort);
    sortOptions.addEventListener('change', filterAndSort);
    renderProducts(products);
}); 