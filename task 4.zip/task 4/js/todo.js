// To-Do/Notes App with Local Storage

document.addEventListener('DOMContentLoaded', function() {
    const newTodoInput = document.getElementById('newTodo');
    const addTodoBtn = document.getElementById('addTodoBtn');
    const todoItems = document.getElementById('todoItems');
    const todoError = document.getElementById('todoError');
    let todos = JSON.parse(localStorage.getItem('task4_todos')) || [];

    function saveTodos() {
        localStorage.setItem('task4_todos', JSON.stringify(todos));
    }
    function renderTodos() {
        todoItems.innerHTML = '';
        if (todos.length === 0) {
            const empty = document.createElement('li');
            empty.textContent = 'No tasks or notes yet.';
            empty.style.opacity = '0.7';
            todoItems.appendChild(empty);
            return;
        }
        todos.forEach(todo => {
            const li = document.createElement('li');
            const span = document.createElement('span');
            span.textContent = todo.text;
            if (todo.completed) span.classList.add('completed');
            span.addEventListener('click', function() {
                todo.completed = !todo.completed;
                saveTodos();
                renderTodos();
            });
            li.appendChild(span);
            const delBtn = document.createElement('button');
            delBtn.textContent = 'Delete';
            delBtn.className = 'delete-btn';
            delBtn.addEventListener('click', function() {
                todos = todos.filter(t => t.id !== todo.id);
                saveTodos();
                renderTodos();
            });
            li.appendChild(delBtn);
            todoItems.appendChild(li);
        });
    }
    function addTodo() {
        const text = newTodoInput.value.trim();
        if (!text) {
            todoError.textContent = 'Please enter a task or note.';
            return;
        }
        todoError.textContent = '';
        todos.push({ id: Date.now(), text, completed: false });
        saveTodos();
        newTodoInput.value = '';
        renderTodos();
    }
    addTodoBtn.addEventListener('click', addTodo);
    newTodoInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') addTodo();
    });
    renderTodos();
}); 