// Portfolio Section Navigation and Contact Form

document.addEventListener('DOMContentLoaded', function() {
    // Simple tab navigation for About, Projects, Contact
    const pages = ['about', 'projects', 'contact'];
    function showPage(page) {
        pages.forEach(p => {
            document.getElementById(p).style.display = (p === page) ? 'block' : 'none';
        });
    }
    // Default to About
    showPage('about');
    document.querySelectorAll('.portfolio-nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('href').replace('#', '');
            showPage(page);
        });
    });

    // Portfolio Contact Form Validation
    const form = document.getElementById('portfolioContactForm');
    const successMsg = document.getElementById('portfolioContactSuccess');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = form.querySelector('input[type="text"]').value.trim();
            const email = form.querySelector('input[type="email"]').value.trim();
            const message = form.querySelector('textarea').value.trim();
            if (!name || !email || !message) {
                successMsg.style.display = 'block';
                successMsg.style.background = '#f8d7da';
                successMsg.style.color = '#721c24';
                successMsg.textContent = 'Please fill in all fields.';
                return;
            }
            // Simple email validation
            if (!/^\S+@\S+\.\S+$/.test(email)) {
                successMsg.style.display = 'block';
                successMsg.style.background = '#f8d7da';
                successMsg.style.color = '#721c24';
                successMsg.textContent = 'Please enter a valid email address.';
                return;
            }
            successMsg.style.display = 'block';
            successMsg.style.background = '#d4edda';
            successMsg.style.color = '#155724';
            successMsg.textContent = 'Message sent successfully!';
            form.reset();
            setTimeout(() => { successMsg.style.display = 'none'; }, 4000);
        });
    }
}); 