// Form Validation
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const formSuccess = document.getElementById('formSuccess');
    
    // Error messages elements
    const nameError = document.getElementById('nameError');
    const emailError = document.getElementById('emailError');
    const phoneError = document.getElementById('phoneError');
    const messageError = document.getElementById('messageError');
    
    // Form input elements
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const messageInput = document.getElementById('message');
    
    // Add event listeners for real-time validation
    nameInput.addEventListener('blur', validateName);
    emailInput.addEventListener('blur', validateEmail);
    phoneInput.addEventListener('blur', validatePhone);
    messageInput.addEventListener('blur', validateMessage);
    
    // Form submission
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Clear previous error messages
        clearErrors();
        
        // Validate all fields
        let isValid = true;
        
        if (!validateName()) isValid = false;
        if (!validateEmail()) isValid = false;
        if (!validatePhone()) isValid = false;
        if (!validateMessage()) isValid = false;
        
        if (isValid) {
            // Form is valid, show success message
            formSuccess.style.display = 'block';
            formSuccess.textContent = 'Form submitted successfully! We will contact you soon.';
            
            // Reset the form
            contactForm.reset();
            
            // Hide success message after 5 seconds
            setTimeout(() => {
                formSuccess.style.display = 'none';
            }, 5000);
        }
    });
    
    // Validation functions
    function validateName() {
        const name = nameInput.value.trim();
        
        if (name === '') {
            nameError.textContent = 'Name is required';
            nameInput.classList.add('error-input');
            return false;
        } else if (name.length < 2) {
            nameError.textContent = 'Name must be at least 2 characters';
            nameInput.classList.add('error-input');
            return false;
        } else {
            nameError.textContent = '';
            nameInput.classList.remove('error-input');
            return true;
        }
    }
    
    function validateEmail() {
        const email = emailInput.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email === '') {
            emailError.textContent = 'Email is required';
            emailInput.classList.add('error-input');
            return false;
        } else if (!emailRegex.test(email)) {
            emailError.textContent = 'Please enter a valid email address';
            emailInput.classList.add('error-input');
            return false;
        } else {
            emailError.textContent = '';
            emailInput.classList.remove('error-input');
            return true;
        }
    }
    
    function validatePhone() {
        const phone = phoneInput.value.trim();
        const phoneRegex = /^\d{10}$/; // Simple validation for 10-digit phone number
        
        if (phone === '') {
            phoneError.textContent = 'Phone number is required';
            phoneInput.classList.add('error-input');
            return false;
        } else if (!phoneRegex.test(phone)) {
            phoneError.textContent = 'Please enter a valid 10-digit phone number';
            phoneInput.classList.add('error-input');
            return false;
        } else {
            phoneError.textContent = '';
            phoneInput.classList.remove('error-input');
            return true;
        }
    }
    
    function validateMessage() {
        const message = messageInput.value.trim();
        
        if (message === '') {
            messageError.textContent = 'Message is required';
            messageInput.classList.add('error-input');
            return false;
        } else if (message.length < 10) {
            messageError.textContent = 'Message must be at least 10 characters';
            messageInput.classList.add('error-input');
            return false;
        } else {
            messageError.textContent = '';
            messageInput.classList.remove('error-input');
            return true;
        }
    }
    
    function clearErrors() {
        nameError.textContent = '';
        emailError.textContent = '';
        phoneError.textContent = '';
        messageError.textContent = '';
        
        nameInput.classList.remove('error-input');
        emailInput.classList.remove('error-input');
        phoneInput.classList.remove('error-input');
        messageInput.classList.remove('error-input');
    }
}); 