// Todo List Functionality
document.addEventListener('DOMContentLoaded', function() {
    const newTodoInput = document.getElementById('newTodo');
    const addTodoBtn = document.getElementById('addTodoBtn');
    const todoItems = document.getElementById('todoItems');
    const todoError = document.getElementById('todoError');
    
    // Load todos from localStorage if available
    let todos = JSON.parse(localStorage.getItem('todos')) || [];
    
    // Initialize the todo list
    renderTodos();
    
    // Add event listener for adding new todos
    addTodoBtn.addEventListener('click', addTodo);
    
    // Add event listener for Enter key
    newTodoInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addTodo();
        }
    });
    
    // Function to add a new todo
    function addTodo() {
        const todoText = newTodoInput.value.trim();
        
        // Validate input
        if (todoText === '') {
            todoError.textContent = 'Please enter a task';
            return;
        }
        
        // Clear error message
        todoError.textContent = '';
        
        // Create new todo object
        const newTodo = {
            id: Date.now(),
            text: todoText,
            completed: false
        };
        
        // Add to todos array
        todos.push(newTodo);
        
        // Save to localStorage
        saveTodos();
        
        // Clear input
        newTodoInput.value = '';
        
        // Render updated todos
        renderTodos();
    }
    
    // Function to render todos
    function renderTodos() {
        // Clear current list
        todoItems.innerHTML = '';
        
        // Check if there are any todos
        if (todos.length === 0) {
            const emptyMessage = document.createElement('p');
            emptyMessage.textContent = 'No tasks yet. Add a new task above!';
            emptyMessage.className = 'empty-message';
            todoItems.appendChild(emptyMessage);
            return;
        }
        
        // Render each todo
        todos.forEach(todo => {
            const li = document.createElement('li');
            li.dataset.id = todo.id;
            
            // Create todo text with checkbox
            const todoTextContainer = document.createElement('div');
            todoTextContainer.className = 'todo-text';
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = todo.completed;
            checkbox.addEventListener('change', function() {
                toggleTodoCompleted(todo.id);
            });
            
            const todoText = document.createElement('span');
            todoText.textContent = todo.text;
            if (todo.completed) {
                todoText.classList.add('completed');
            }
            
            todoTextContainer.appendChild(checkbox);
            todoTextContainer.appendChild(todoText);
            
            // Create actions container
            const actionsContainer = document.createElement('div');
            actionsContainer.className = 'actions';
            
            // Create delete button
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-btn';
            deleteBtn.textContent = 'Delete';
            deleteBtn.addEventListener('click', function() {
                deleteTodo(todo.id);
            });
            
            actionsContainer.appendChild(deleteBtn);
            
            // Append everything to the li
            li.appendChild(todoTextContainer);
            li.appendChild(actionsContainer);
            
            // Append li to the todoItems ul
            todoItems.appendChild(li);
        });
    }
    
    // Function to toggle completed status
    function toggleTodoCompleted(id) {
        todos = todos.map(todo => {
            if (todo.id === id) {
                return {
                    ...todo,
                    completed: !todo.completed
                };
            }
            return todo;
        });
        
        saveTodos();
        renderTodos();
    }
    
    // Function to delete a todo
    function deleteTodo(id) {
        todos = todos.filter(todo => todo.id !== id);
        saveTodos();
        renderTodos();
    }
    
    // Function to save todos to localStorage
    function saveTodos() {
        localStorage.setItem('todos', JSON.stringify(todos));
    }
}); 