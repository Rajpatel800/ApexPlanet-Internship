# Task 2 - Web Development Project

This is a web development project for ApexPlanet Software Pvt Ltd, showcasing intermediate HTML, CSS, and JavaScript skills.

## Project Overview

This project demonstrates the following skills:

1. Creating a responsive web layout using Flexbox and CSS Grid
2. Building and styling a contact form with various input fields
3. Implementing form validation using JavaScript
4. Creating a dynamic to-do list using JavaScript DOM manipulation

## Features

### Contact Form
- Includes input fields for name, email, phone, and message
- Real-time validation for all fields
- Success message displayed on successful form submission

### To-Do List
- Add new tasks to the list
- Mark tasks as completed
- Delete tasks from the list
- Tasks are saved in localStorage for persistence

## Technologies Used

- HTML5
- CSS3 (Flexbox, Grid, Media Queries)
- JavaScript (ES6+)
- Local Storage API

## Project Structure

```
task2/
├── css/
│   └── style.css
├── js/
│   ├── validation.js
│   └── todo.js
├── index.html
└── README.md
```

## How to Run

1. Clone or download this repository
2. Open the `index.html` file in any modern web browser
3. No build process or dependencies are required

## Responsive Design

The layout adapts to different screen sizes:
- Desktop: Two-column layout with contact form and to-do list side by side
- Mobile: Single column layout with stacked components

## Future Improvements

- Add more input types to the form
- Implement task editing functionality
- Add due dates to tasks
- Implement task categories or tags
- Add drag and drop for task reordering

## License

This project is created as part of a technical assessment for ApexPlanet Software Pvt Ltd. 